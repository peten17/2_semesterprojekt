package com.ur.urcap.sample.sendScriptWithButton.impl;

// API stuff imported
import com.ur.urcap.api.contribution.ProgramNodeContribution;
import com.ur.urcap.api.domain.URCapAPI;
import com.ur.urcap.api.domain.data.DataModel;
import com.ur.urcap.api.domain.script.ScriptWriter;
import com.ur.urcap.api.ui.annotation.Input;
import com.ur.urcap.api.ui.annotation.Label;
import com.ur.urcap.api.ui.component.InputButton;
import com.ur.urcap.api.ui.component.InputEvent;
import com.ur.urcap.api.ui.component.InputTextField;
import com.ur.urcap.api.ui.component.LabelComponent;
// Import the "clientSendScript" class
import com.ur.urcap.sample.sendScriptWithButton.impl.clientSendScript;

public class sendScriptButtonsProgramNodeContribution implements ProgramNodeContribution {

	private final URCapAPI urCapAPI;
	private final DataModel dataModel;

	public sendScriptButtonsProgramNodeContribution(URCapAPI urCapAPI, DataModel dataModel) {
		this.urCapAPI = urCapAPI;
		this.dataModel = dataModel;
	}
	
	// Include the "clientSendScript" class as "scriptSender"
	clientSendScript scriptSender = new clientSendScript();
	
	// Just a pose, that is used for moving the robot... 
	private String myPose = "p[0.0,-0.3,0.1,0,3.1415,0]";
	
	/************************
	 * GUI INTERACTION METHODS
	 ************************/
	
	// Define GUI components
	@Input(id="btn_sendMove")
	InputButton BTN_SendMove;
	
	@Input(id="btn_sendPopup")
	InputButton BTN_SendPopup;
	
	@Label(id="lbl_pose")
	LabelComponent LBL_Pose;
	
	@Input(id="txt_popupMessage")
	InputTextField TXT_PopupMessage;
	
	@Input(id="btn_sendMove")
	public void onSendMoveClick(InputEvent event){
		if(event.getEventType() == InputEvent.EventType.ON_RELEASED){
			scriptSender.sendMoveJ(myPose);
		}
	}
	
	@Input(id="btn_sendPopup")
	public void onSendPopupClick(InputEvent event){
		if(event.getEventType() == InputEvent.EventType.ON_RELEASED){
				// Event can only be called, if text is set - otherwise button is inactive
				scriptSender.createPopup(getPopupText());
		}
	}
	
	@Input(id="txt_popupMessage")
	public void onPopupTextChange(InputEvent event){
		if(event.getEventType() == InputEvent.EventType.ON_CHANGE){
			setPopupText(TXT_PopupMessage.getText());
		}
	}
	
	private void setPopupButtonState(){
		if(!getPopupText().equals("")){
			BTN_SendPopup.setEnabled(true);
		}
		else{
			BTN_SendPopup.setEnabled(false);
		}
	}
	
	/************************
	 * OVERWRITTEN METHODS
	 ************************/

	@Override
	public void openView() {
		BTN_SendMove.setText("Move robot");
		BTN_SendPopup.setText("Show popup");
		TXT_PopupMessage.setText(getPopupText());
		LBL_Pose.setText(myPose);
		setPopupButtonState();
	}

	@Override
	public void closeView() {}

	@Override
	public String getTitle() {
		return "SendSomeScript";
	}

	@Override
	public boolean isDefined() {
		return true;
	}

	@Override
	public void generateScript(ScriptWriter writer) {}
	
	private static final String KEY_POPUPTEXT = "key_for_popuptext";
	private void setPopupText(String text){
		dataModel.set(KEY_POPUPTEXT, text);
		setPopupButtonState();
	}
	private String getPopupText(){
		return dataModel.get(KEY_POPUPTEXT, "");
	}

}
